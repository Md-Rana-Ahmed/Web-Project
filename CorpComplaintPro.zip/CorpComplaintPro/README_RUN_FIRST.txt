CorpComplaint Pro — Corporate Complaint Management System (XAMPP Ready)

1) Copy folder to htdocs as: CorpComplaintPro
2) Start XAMPP (Apache + MySQL)
3) Open: http://localhost/CorpComplaintPro/index.php

Demo accounts:
- admin@corp.local / Admin@123
- staff@corp.local / Staff@123
- employee@corp.local / Employee@123
