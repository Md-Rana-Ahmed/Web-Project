<?php
return [
  'app' => [
    'name' => 'CorpComplaint Pro',
    'timezone' => 'Asia/Dhaka',
    'company' => 'Your Company Ltd.',
  ],
  'db' => [
    'host' => '127.0.0.1',
    'name' => 'corp_complaint_pro',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
  ],
  'security' => [
    'session_name' => 'corpcomplaintpro_session',
    'csrf_secret' => 'change-this-secret',
  ],
  'ai' => [
    'openai_api_key' => '',
    'openai_model' => 'gpt-4o-mini',
    'use_openai_if_available' => true,
  ],
  'mail' => [
    'mode' => 'log',
    'from' => 'no-reply@corp.local',
  ]
];
