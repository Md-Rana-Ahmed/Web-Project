<?php
[$config, $db] = require __DIR__ . '/src/bootstrap.php';

use App\Support\Auth;
use App\Support\Logger;
use App\Support\Mailer;
use App\Support\Util;
use App\Smart\SmartAssist;

$page = $_GET['p'] ?? 'dashboard';
$flash = $_SESSION['_flash'] ?? null;
unset($_SESSION['_flash']);

function set_flash($type, $msg) { $_SESSION['_flash'] = ['type'=>$type,'msg'=>$msg]; }

if ($page === 'login') {
  $title = "Login";
  require __DIR__ . '/views/pages/login.php';
  exit;
}
if ($page === 'login_do') {
  csrf_check();
  $email = trim($_POST['email'] ?? '');
  $pass = $_POST['password'] ?? '';
  if (Auth::attempt($db, $email, $pass)) {
    set_flash('success', 'Welcome back!');
    redirect('index.php?p=dashboard');
  }
  set_flash('danger', 'Invalid login.');
  redirect('index.php?p=login');
}
if ($page === 'logout') {
  csrf_check();
  Auth::logout();
  redirect('index.php?p=login');
}

$user = Auth::require($db);

function render($view, $data=[]) { extract($data); require __DIR__ . '/views/pages/'.$view.'.php'; }

// Actions
if ($page === 'complaint_create') {
  csrf_check();
  $subject = trim($_POST['subject'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $department_id = (int)($_POST['department_id'] ?? 0);
  $channel = $_POST['channel'] ?? 'Web';

  if ($subject==='' || $description==='' || $department_id<=0) {
    set_flash('danger','Please fill all required fields.');
    redirect('index.php?p=new_complaint');
  }

  $ai = SmartAssist::analyze($db, $config, $subject."\n".$description);

  $st = $db->prepare("SELECT sla_hours FROM departments WHERE id=?");
  $st->execute([$department_id]);
  $slaH = (int)($st->fetchColumn() ?: 72);
  $due = date('Y-m-d H:i:s', time() + $slaH*3600);

  $assignee = $db->query("SELECT id FROM users WHERE role IN ('staff','admin') AND is_active=1 ORDER BY role='admin' DESC, id ASC LIMIT 1")->fetchColumn();

  $code = Util::code();
  $now = now();

  $st = $db->prepare("INSERT INTO complaints
    (code,subject,description,department_id,category,priority,sentiment,status,channel,submitter_id,assignee_id,due_at,ai_summary,ai_suggested_response,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
  $st->execute([
    $code,$subject,$description,$department_id,
    $ai['category'] ?? 'General',
    $ai['priority'] ?? 'Medium',
    $ai['sentiment'] ?? 'Neutral',
    'New',$channel,$user['id'],$assignee,$due,
    $ai['summary'] ?? null,
    $ai['suggested_response'] ?? null,
    $now,$now
  ]);

  $cid = (int)$db->lastInsertId();
  Logger::log($db, (int)$user['id'], 'complaint_created', "Complaint $code created.");

  Mailer::send($db,$config,$user['email'],"Complaint submitted: $code","Code: $code\nSubject: $subject\nStatus: New");

  set_flash('success',"Complaint submitted. Code: $code");
  redirect('index.php?p=complaint_view&id='.$cid);
}

if ($page === 'complaint_message') {
  csrf_check();
  $cid = (int)($_POST['complaint_id'] ?? 0);
  $msg = trim($_POST['message'] ?? '');
  $internal = (int)($_POST['is_internal'] ?? 0);
  if ($user['role']==='employee') $internal=0;

  if ($msg==='' || $cid<=0) { set_flash('danger','Message cannot be empty.'); redirect('index.php?p=complaints'); }

  $st=$db->prepare("SELECT submitter_id, code FROM complaints WHERE id=?");
  $st->execute([$cid]);
  $row=$st->fetch();
  if (!$row) { http_response_code(404); exit('Not found'); }
  if ($user['role']==='employee' && (int)$row['submitter_id'] !== (int)$user['id']) { http_response_code(403); exit('Forbidden'); }

  $db->prepare("INSERT INTO complaint_messages (complaint_id,user_id,message,is_internal,created_at) VALUES (?,?,?,?,?)")
     ->execute([$cid,$user['id'],$msg,$internal,now()]);
  $db->prepare("UPDATE complaints SET updated_at=? WHERE id=?")->execute([now(),$cid]);

  Logger::log($db, (int)$user['id'], 'message_added', "Message added to complaint ".$row['code']);
  set_flash('success','Message posted.');
  redirect('index.php?p=complaint_view&id='.$cid);
}

// Views
switch ($page) {
  case 'dashboard':      render('dashboard', compact('config','db','user','flash','page')); break;
  case 'complaints':     render('complaints', compact('config','db','user','flash','page')); break;
  case 'new_complaint':  render('new_complaint', compact('config','db','user','flash','page')); break;
  case 'complaint_view': render('complaint_view', compact('config','db','user','flash','page')); break;
  case 'users':          render('users', compact('config','db','user','flash','page')); break;
  case 'departments':    render('departments', compact('config','db','user','flash','page')); break;
  case 'mail':           render('mail', compact('config','db','user','flash','page')); break;
  case 'settings':       render('settings', compact('config','db','user','flash','page')); break;
  case 'profile':        render('profile', compact('config','db','user','flash','page')); break;
  case 'reports':        render('reports', compact('config','db','user','flash','page')); break;
  case 'knowledge':      render('knowledge', compact('config','db','user','flash','page')); break;
  default:
    http_response_code(404);
    echo "404 Not Found";
}
