<?php
$title="Dashboard";
$subtitle="Live overview and KPIs.";
require __DIR__ . '/../partials/header.php';

$total = (int)$db->query("SELECT COUNT(*) FROM complaints")->fetchColumn();
$new = (int)$db->query("SELECT COUNT(*) FROM complaints WHERE status='New'")->fetchColumn();
$open = (int)$db->query("SELECT COUNT(*) FROM complaints WHERE status IN ('New','In Review','Assigned')")->fetchColumn();

$rows = $db->query("SELECT status, COUNT(*) c FROM complaints GROUP BY status")->fetchAll();
$labels = array_map(fn($r)=>$r['status'], $rows);
$counts = array_map(fn($r)=>(int)$r['c'], $rows);
?>
<div class="d-flex">
  <?php require __DIR__ . '/../partials/sidebar.php'; ?>
  <div class="flex-grow-1 p-4">
    <?php require __DIR__ . '/../partials/topbar.php'; ?>
    <div class="row g-3 mb-3">
      <div class="col-md-4"><div class="card card-glass rounded-4 p-3"><div class="text-white-50">Total</div><div class="kpi"><?= $total ?></div></div></div>
      <div class="col-md-4"><div class="card card-glass rounded-4 p-3"><div class="text-white-50">New</div><div class="kpi"><?= $new ?></div></div></div>
      <div class="col-md-4"><div class="card card-glass rounded-4 p-3"><div class="text-white-50">Open</div><div class="kpi"><?= $open ?></div></div></div>
    </div>
    <div class="card card-glass rounded-4 p-3">
      <div class="fw-bold">Status distribution</div>
      <div class="mt-3"><canvas id="chart" height="220"></canvas></div>
    </div>
    <script>
      new Chart(document.getElementById('chart'),{type:'doughnut',data:{labels:<?= json.dumps(labels) ?>,datasets:[{data:<?= json.dumps(counts) ?>}]} ,options:{plugins:{legend:{labels:{color:'#e5e7eb'}}}}});
    </script>
  </div>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
