<?php
$id=(int)($_GET['id'] ?? 0);
$st=$db->prepare("SELECT c.*, d.name dept, u.name submitter FROM complaints c JOIN departments d ON d.id=c.department_id JOIN users u ON u.id=c.submitter_id WHERE c.id=?");
$st->execute([$id]);
$c=$st->fetch();
if(!$c){ http_response_code(404); exit('Not found'); }
if($user['role']==='employee' && (int)$c['submitter_id']!==(int)$user['id']){ http_response_code(403); exit('Forbidden'); }

$title="Complaint ".$c['code'];
$subtitle=$c['subject'];
require __DIR__ . '/../partials/header.php';

$msgs=$db->prepare("SELECT m.*, u.name, u.role FROM complaint_messages m JOIN users u ON u.id=m.user_id WHERE m.complaint_id=? ORDER BY m.created_at ASC");
$msgs->execute([$id]); $msgs=$msgs->fetchAll();

?>
<div class="d-flex">
  <?php require __DIR__ . '/../partials/sidebar.php'; ?>
  <div class="flex-grow-1 p-4">
    <?php require __DIR__ . '/../partials/topbar.php'; ?>
    <div class="row g-3">
      <div class="col-lg-7">
        <div class="card card-glass rounded-4 p-3 mb-3">
          <div class="fw-bold">Details</div>
          <div class="text-white-50 small">Dept: <?= e($c['dept']) ?> · Status: <?= e($c['status']) ?> · Priority: <?= e($c['priority']) ?></div>
          <hr class="border-white border-opacity-10">
          <div class="text-white-50" style="white-space:pre-wrap;"><?= e($c['description']) ?></div>
        </div>
        <div class="card card-glass rounded-4 p-3">
          <div class="fw-bold">Conversation</div>
          <hr class="border-white border-opacity-10">
          <?php foreach($msgs as $m): ?>
            <?php if ((int)$m['is_internal']===1 && $user['role']==='employee') continue; ?>
            <div class="mb-3">
              <div class="d-flex justify-content-between">
                <div class="fw-semibold"><?= e($m['name']) ?> <?= role_badge($m['role']) ?> <?php if ((int)$m['is_internal']===1) echo '<span class="badge bg-warning text-dark">Internal</span>'; ?></div>
                <div class="text-white-50 small"><?= e($m['created_at']) ?></div>
              </div>
              <div class="text-white-50" style="white-space:pre-wrap;"><?= e($m['message']) ?></div>
            </div>
          <?php endforeach; ?>

          <form method="post" action="index.php?p=complaint_message">
            <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="complaint_id" value="<?= (int)$c['id'] ?>">
            <textarea class="form-control mb-2" rows="3" name="message" required></textarea>
            <?php if (in_array($user['role'],['admin','staff'],true)): ?>
              <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="is_internal" value="1" id="internal">
                <label class="form-check-label text-white-50" for="internal">Internal note</label>
              </div>
            <?php endif; ?>
            <button class="btn btn-primary"><i class="bi bi-chat-dots me-1"></i>Post</button>
          </form>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="card card-glass rounded-4 p-3">
          <div class="fw-bold">Smart Assist</div>
          <div class="text-white-50 small">Summary & suggested response</div>
          <hr class="border-white border-opacity-10">
          <div class="text-white-50"><div class="fw-semibold small">Summary</div><?= e($c['ai_summary'] ?? '—') ?></div>
          <hr class="border-white border-opacity-10">
          <div class="text-white-50"><div class="fw-semibold small">Suggested response</div><?= e($c['ai_suggested_response'] ?? '—') ?></div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
