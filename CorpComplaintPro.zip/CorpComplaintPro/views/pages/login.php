<?php require __DIR__ . '/../partials/header.php'; ?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-6">
      <div class="card card-glass rounded-4">
        <div class="card-body p-4 p-lg-5">
          <div class="d-flex align-items-center gap-3 mb-3">
            <div class="rounded-4 d-flex align-items-center justify-content-center" style="width:48px;height:48px;background:linear-gradient(135deg,#4f46e5,#14b8a6);color:#061022;font-weight:900;">CC</div>
            <div>
              <div class="h3 mb-0 fw-bold"><?= e(cfg()['app']['name'] ?? 'CorpComplaint Pro') ?></div>
              <div class="text-white-50">Secure corporate complaint operations</div>
            </div>
          </div>

          <?php if (!empty($flash)): ?>
            <div class="alert alert-<?= e($flash['type']) ?> rounded-4" data-autohide="toast"><?= e($flash['msg']) ?></div>
          <?php endif; ?>

          <form method="post" action="index.php?p=login_do" class="mt-3">
            <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input class="form-control form-control-lg" name="email" type="email" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input class="form-control form-control-lg" name="password" type="password" required>
            </div>
            <button class="btn btn-primary btn-lg w-100" type="submit"><i class="bi bi-shield-lock me-2"></i>Sign in</button>
          </form>

          <hr class="border-white border-opacity-10 my-4">
          <div class="small text-white-50">
            Demo accounts:<br>
            <span class="mono">admin@corp.local / Admin@123</span><br>
            <span class="mono">staff@corp.local / Staff@123</span><br>
            <span class="mono">employee@corp.local / Employee@123</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
