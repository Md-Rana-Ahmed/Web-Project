<?php
$title="Knowledge Base"; $subtitle="Content module";
require __DIR__ . '/../partials/header.php';
?>
<div class="d-flex">
  <?php require __DIR__ . '/../partials/sidebar.php'; ?>
  <div class="flex-grow-1 p-4">
    <?php require __DIR__ . '/../partials/topbar.php'; ?>
    <div class="card card-glass rounded-4 p-4">
      <div class="text-white-50">This module is enabled in the Pro build. All routing is connected correctly.</div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
