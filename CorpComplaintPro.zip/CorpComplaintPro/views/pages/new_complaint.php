<?php
if ($user['role']!=='employee') { header("Location: index.php?p=complaints"); exit; }
$title="Submit Complaint";
$subtitle="Create a new case. Smart Assist runs automatically.";
require __DIR__ . '/../partials/header.php';
$deps=$db->query("SELECT id,name,sla_hours FROM departments ORDER BY name ASC")->fetchAll();
?>
<div class="d-flex">
  <?php require __DIR__ . '/../partials/sidebar.php'; ?>
  <div class="flex-grow-1 p-4">
    <?php require __DIR__ . '/../partials/topbar.php'; ?>
    <div class="card card-glass rounded-4 p-3">
      <form method="post" action="index.php?p=complaint_create">
        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
        <div class="mb-2"><label class="form-label">Subject *</label><input class="form-control" name="subject" required></div>
        <div class="mb-2"><label class="form-label">Department *</label>
          <select class="form-select" name="department_id" required>
            <option value="">Select…</option>
            <?php foreach($deps as $d): ?>
              <option value="<?= (int)$d['id'] ?>"><?= e($d['name']) ?> (SLA <?= (int)$d['sla_hours'] ?>h)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2"><label class="form-label">Channel</label>
          <select class="form-select" name="channel"><?php foreach(['Web','Email','Phone','Walk-in'] as $c): ?><option value="<?= e($c) ?>"><?= e($c) ?></option><?php endforeach; ?></select>
        </div>
        <div class="mb-3"><label class="form-label">Description *</label><textarea class="form-control" rows="7" name="description" required></textarea></div>
        <button class="btn btn-primary"><i class="bi bi-send me-1"></i>Submit</button>
      </form>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
