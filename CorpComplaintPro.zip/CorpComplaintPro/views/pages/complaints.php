<?php
$title="Complaints";
$subtitle="Full queue with working navigation.";
require __DIR__ . '/../partials/header.php';

$where=[];$params=[];
if ($user['role']==='employee'){ $where[]="c.submitter_id=?"; $params[]=$user['id']; }
$sqlWhere = $where ? "WHERE ".implode(" AND ",$where) : "";

$st=$db->prepare("SELECT c.id,c.code,c.subject,c.priority,c.status,c.updated_at,d.name dept FROM complaints c JOIN departments d ON d.id=c.department_id $sqlWhere ORDER BY c.updated_at DESC");
$st->execute($params);
$items=$st->fetchAll();
?>
<div class="d-flex">
  <?php require __DIR__ . '/../partials/sidebar.php'; ?>
  <div class="flex-grow-1 p-4">
    <?php require __DIR__ . '/../partials/topbar.php'; ?>
    <div class="card card-glass rounded-4 p-3">
      <div class="table-responsive">
        <table id="tbl" class="table table-dark table-hover align-middle">
          <thead><tr><th>Code</th><th>Subject</th><th>Dept</th><th>Priority</th><th>Status</th><th>Updated</th><th></th></tr></thead>
          <tbody>
          <?php foreach($items as $c): ?>
            <tr>
              <td class="mono"><?= e($c['code']) ?></td>
              <td><?= e($c['subject']) ?></td>
              <td><?= e($c['dept']) ?></td>
              <td><span class="badge bg-info text-dark"><?= e($c['priority']) ?></span></td>
              <td><span class="badge bg-secondary"><?= e($c['status']) ?></span></td>
              <td class="text-white-50 small"><?= e($c['updated_at']) ?></td>
              <td><a class="btn btn-sm btn-outline-info" href="index.php?p=complaint_view&id=<?= (int)$c['id'] ?>"><i class="bi bi-box-arrow-in-right"></i></a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <script>$(function(){ $('#tbl').DataTable({pageLength:25}); });</script>
  </div>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
