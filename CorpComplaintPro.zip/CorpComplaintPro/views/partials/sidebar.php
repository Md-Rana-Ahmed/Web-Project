<?php
$u = $user ?? null;
$p = $page ?? '';
?>
<div class="sidebar p-3 position-sticky top-0">
  <div class="d-flex align-items-center gap-2 mb-3">
    <div class="rounded-4 d-flex align-items-center justify-content-center" style="width:42px;height:42px;background:linear-gradient(135deg,#4f46e5,#14b8a6);color:#061022;font-weight:900;">CC</div>
    <div>
      <div class="fw-bold"><?= e(cfg()['app']['name'] ?? 'CorpComplaint Pro') ?></div>
      <div class="small text-white-50">Complaint Operations</div>
    </div>
  </div>

  <div class="small text-white-50 mb-2">MAIN</div>
  <div class="nav nav-pills flex-column gap-2">
    <a class="nav-link <?= $p==='dashboard'?'active':'' ?>" href="index.php?p=dashboard"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
    <a class="nav-link <?= $p==='complaints'?'active':'' ?>" href="index.php?p=complaints"><i class="bi bi-inboxes me-2"></i>Complaints</a>
    <?php if (($u['role'] ?? '')==='employee'): ?>
      <a class="nav-link <?= $p==='new_complaint'?'active':'' ?>" href="index.php?p=new_complaint"><i class="bi bi-plus-circle me-2"></i>Submit Complaint</a>
      <a class="nav-link <?= $p==='my_complaints'?'active':'' ?>" href="index.php?p=my_complaints"><i class="bi bi-person-lines-fill me-2"></i>My Complaints</a>
    <?php endif; ?>
  </div>

  <?php if (($u['role'] ?? '')==='admin'): ?>
    <div class="small text-white-50 mt-4 mb-2">ADMIN</div>
    <div class="nav nav-pills flex-column gap-2">
      <a class="nav-link <?= $p==='users'?'active':'' ?>" href="index.php?p=users"><i class="bi bi-people me-2"></i>Users</a>
      <a class="nav-link <?= $p==='departments'?'active':'' ?>" href="index.php?p=departments"><i class="bi bi-building me-2"></i>Departments & SLA</a>
      <a class="nav-link <?= $p==='mail'?'active':'' ?>" href="index.php?p=mail"><i class="bi bi-envelope-paper me-2"></i>Mail Log</a>
      <a class="nav-link <?= $p==='settings'?'active':'' ?>" href="index.php?p=settings"><i class="bi bi-gear me-2"></i>Settings</a>
    </div>
  <?php endif; ?>

  <div class="mt-4 p-3 rounded-4" style="background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08);">
    <div class="small text-white-50">Signed in as</div>
    <div class="fw-semibold"><?= e($u['name'] ?? 'Guest') ?></div>
    <div class="small text-white-50"><?= e($u['email'] ?? '') ?></div>
    <div class="mt-2"><?= role_badge($u['role'] ?? 'guest') ?></div>
  </div>
</div>
