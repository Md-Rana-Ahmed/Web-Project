<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <div class="h4 mb-0 fw-bold"><?= e($title ?? '') ?></div>
    <div class="text-white-50 small"><?= e($subtitle ?? '') ?></div>
  </div>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-light btn-sm" href="index.php?p=profile"><i class="bi bi-person-circle me-1"></i>Profile</a>
    <form method="post" action="index.php?p=logout" class="m-0">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <button class="btn btn-outline-light btn-sm" type="submit"><i class="bi bi-box-arrow-right me-1"></i>Logout</button>
    </form>
  </div>
</div>
