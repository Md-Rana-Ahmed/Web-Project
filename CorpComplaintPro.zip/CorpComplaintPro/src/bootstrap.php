<?php
$config = require __DIR__ . '/../config.php';
date_default_timezone_set($config['app']['timezone'] ?? 'UTC');

spl_autoload_register(function($class){
  $prefix = 'App\\';
  if (strpos($class, $prefix) !== 0) return;
  $rel = substr($class, strlen($prefix));
  $file = __DIR__ . '/' . str_replace('\\','/',$rel) . '.php';
  if (file_exists($file)) require $file;
});

require __DIR__ . '/helpers.php';

session_name($config['security']['session_name'] ?? 'PHPSESSID');
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(16));

$GLOBALS['APP_CONFIG'] = $config;

$db = \App\Support\DB::pdo($config);
\App\Support\Migrator::migrateAndSeed($db);

return [$config, $db];
