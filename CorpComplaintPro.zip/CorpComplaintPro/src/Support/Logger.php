<?php
namespace App\Support;
use PDO;

class Logger {
  public static function log(PDO $db, ?int $actorId, string $action, string $detail): void {
    $st = $db->prepare("INSERT INTO activity_log (actor_id, action, detail, created_at) VALUES (?,?,?,?)");
    $st->execute([$actorId, $action, $detail, date('Y-m-d H:i:s')]);
  }
}
