<?php
namespace App\Support;
use PDO;

class Auth {
  public static function user(PDO $db): ?array {
    $id = $_SESSION['uid'] ?? null;
    if (!$id) return null;
    $st=$db->prepare("SELECT id,name,email,role,department,is_active FROM users WHERE id=? LIMIT 1");
    $st->execute([$id]);
    return $st->fetch() ?: null;
  }
  public static function require(PDO $db): array {
    $u=self::user($db);
    if (!$u) { header("Location: index.php?p=login"); exit; }
    if ((int)$u['is_active'] !== 1) { session_destroy(); exit('Account disabled'); }
    return $u;
  }
  public static function requireRole(PDO $db, array $roles): array {
    $u=self::require($db);
    if (!in_array($u['role'], $roles, true)) { http_response_code(403); exit('Forbidden'); }
    return $u;
  }
  public static function attempt(PDO $db, string $email, string $pass): bool {
    $st=$db->prepare("SELECT id,password_hash,is_active FROM users WHERE email=? LIMIT 1");
    $st->execute([$email]);
    $r=$st->fetch();
    if (!$r || (int)$r['is_active']!==1) return false;
    if (!password_verify($pass, $r['password_hash'])) return false;
    $_SESSION['uid'] = (int)$r['id'];
    return true;
  }
  public static function logout(): void { session_destroy(); }
}
