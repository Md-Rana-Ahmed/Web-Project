<?php
namespace App\Support;
use PDO;

class Mailer {
  public static function send(PDO $db, array $config, string $to, string $subject, string $body): void {
    $st=$db->prepare("INSERT INTO mail_log (to_email, subject, body, created_at) VALUES (?,?,?,?)");
    $st->execute([$to,$subject,$body,date('Y-m-d H:i:s')]);
    $logPath = __DIR__ . '/../../storage/mail.log';
    @file_put_contents($logPath, "[".date('c')."] TO:$to | $subject\n$body\n\n", FILE_APPEND);
  }
}
