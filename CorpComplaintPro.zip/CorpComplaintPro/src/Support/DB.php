<?php
namespace App\Support;
use PDO;

class DB {
  public static function pdo(array $config): PDO {
    $db = $config['db'];
    $host=$db['host']; $name=$db['name']; $user=$db['user']; $pass=$db['pass'];
    $charset=$db['charset'] ?? 'utf8mb4';

    $pdoServer = new PDO("mysql:host={$host};charset={$charset}", $user, $pass, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdoServer->exec("CREATE DATABASE IF NOT EXISTS `{$name}` CHARACTER SET {$charset} COLLATE utf8mb4_unicode_ci");

    return new PDO("mysql:host={$host};dbname={$name};charset={$charset}", $user, $pass, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
  }
}
