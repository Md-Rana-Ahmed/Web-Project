<?php
namespace App\Support;
use PDO;

class Migrator {
  public static function migrateAndSeed(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS app_meta (k VARCHAR(50) PRIMARY KEY, v VARCHAR(255) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $v = $db->query("SELECT v FROM app_meta WHERE k='schema_version'")->fetchColumn();
    $v = $v ? (int)$v : 0;

    if ($v < 1) {
      self::v1($db);
      $db->prepare("REPLACE INTO app_meta (k,v) VALUES ('schema_version','1')")->execute();
      self::seed($db);
    }
  }

  private static function v1(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      email VARCHAR(190) NOT NULL UNIQUE,
      role ENUM('admin','staff','employee') NOT NULL DEFAULT 'employee',
      department VARCHAR(80) NOT NULL DEFAULT 'General',
      password_hash VARCHAR(255) NOT NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS departments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(80) NOT NULL UNIQUE,
      sla_hours INT NOT NULL DEFAULT 72,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS complaints (
      id INT AUTO_INCREMENT PRIMARY KEY,
      code VARCHAR(24) NOT NULL UNIQUE,
      subject VARCHAR(200) NOT NULL,
      description TEXT NOT NULL,
      department_id INT NOT NULL,
      category VARCHAR(60) NOT NULL DEFAULT 'General',
      priority ENUM('Low','Medium','High','Critical') NOT NULL DEFAULT 'Medium',
      sentiment ENUM('Positive','Neutral','Negative') NOT NULL DEFAULT 'Neutral',
      status ENUM('New','In Review','Assigned','Resolved','Closed') NOT NULL DEFAULT 'New',
      channel ENUM('Web','Email','Phone','Walk-in') NOT NULL DEFAULT 'Web',
      submitter_id INT NOT NULL,
      assignee_id INT NULL,
      due_at DATETIME NULL,
      ai_summary TEXT NULL,
      ai_suggested_response TEXT NULL,
      created_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL,
      FOREIGN KEY (department_id) REFERENCES departments(id),
      FOREIGN KEY (submitter_id) REFERENCES users(id),
      FOREIGN KEY (assignee_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS complaint_messages (
      id INT AUTO_INCREMENT PRIMARY KEY,
      complaint_id INT NOT NULL,
      user_id INT NOT NULL,
      message TEXT NOT NULL,
      is_internal TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS attachments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      complaint_id INT NOT NULL,
      uploaded_by INT NOT NULL,
      original_name VARCHAR(255) NOT NULL,
      stored_name VARCHAR(255) NOT NULL,
      mime VARCHAR(120) NOT NULL,
      size_bytes INT NOT NULL,
      created_at DATETIME NOT NULL,
      FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
      FOREIGN KEY (uploaded_by) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS activity_log (
      id INT AUTO_INCREMENT PRIMARY KEY,
      actor_id INT NULL,
      action VARCHAR(80) NOT NULL,
      detail TEXT NOT NULL,
      created_at DATETIME NOT NULL,
      FOREIGN KEY (actor_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS mail_log (
      id INT AUTO_INCREMENT PRIMARY KEY,
      to_email VARCHAR(190) NOT NULL,
      subject VARCHAR(200) NOT NULL,
      body TEXT NOT NULL,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }

  private static function seed(PDO $db): void {
    $now = date('Y-m-d H:i:s');

    $deps = [['HR',48],['IT Support',24],['Facilities',72],['Finance',72],['Security',12],['General',72]];
    $st = $db->prepare("INSERT IGNORE INTO departments (name,sla_hours,created_at) VALUES (?,?,?)");
    foreach ($deps as $d) $st->execute([$d[0],$d[1],$now]);

    $users = [
      ['Admin','admin@corp.local','admin','General','Admin@123'],
      ['Support Staff','staff@corp.local','staff','IT Support','Staff@123'],
      ['Employee User','employee@corp.local','employee','General','Employee@123'],
    ];
    $su=$db->prepare("INSERT IGNORE INTO users (name,email,role,department,password_hash,created_at) VALUES (?,?,?,?,?,?)");
    foreach ($users as $u) $su->execute([$u[0],$u[1],$u[2],$u[3],password_hash($u[4], PASSWORD_BCRYPT),$now]);

    $emp=(int)$db->query("SELECT id FROM users WHERE email='employee@corp.local'")->fetchColumn();
    $staff=(int)$db->query("SELECT id FROM users WHERE email='staff@corp.local'")->fetchColumn();
    $depIT=(int)$db->query("SELECT id FROM departments WHERE name='IT Support'")->fetchColumn();

    $code='CCP-DEMO000001';
    $due=date('Y-m-d H:i:s', time()+24*3600);
    $db->prepare("INSERT IGNORE INTO complaints (code,subject,description,department_id,category,priority,sentiment,status,channel,submitter_id,assignee_id,due_at,ai_summary,ai_suggested_response,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
      ->execute([$code,'VPN not connecting','Cannot connect to VPN since yesterday. Please resolve urgently.',$depIT,'IT Support','High','Negative','New','Web',$emp,$staff,$due,'VPN issue affecting remote work.','Sorry for the inconvenience. We will prioritize this and respond urgently.',$now,$now]);
  }
}
