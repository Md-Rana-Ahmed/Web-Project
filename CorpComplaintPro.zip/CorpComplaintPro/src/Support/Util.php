<?php
namespace App\Support;

class Util {
  public static function code(): string {
    $alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $out='CCP-';
    for ($i=0;$i<10;$i++) $out.=$alphabet[random_int(0, strlen($alphabet)-1)];
    return $out;
  }
  public static function safeFilename(string $name): string {
    $name = preg_replace('/[^A-Za-z0-9\.\-\_]+/', '_', $name);
    return trim($name,'_');
  }
}
