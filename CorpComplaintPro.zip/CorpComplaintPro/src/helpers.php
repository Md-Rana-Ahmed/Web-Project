<?php
function cfg() { return $GLOBALS['APP_CONFIG'] ?? []; }
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf_token() { return $_SESSION['_csrf'] ?? ''; }
function csrf_check() {
  $t = $_POST['_csrf'] ?? '';
  if (!$t || !hash_equals($_SESSION['_csrf'] ?? '', $t)) {
    http_response_code(419);
    exit('CSRF token mismatch. Please refresh and try again.');
  }
}
function redirect($url) { header("Location: $url"); exit; }
function now() { return date('Y-m-d H:i:s'); }
function role_badge($role){
  $map = ['admin'=>'danger','staff'=>'primary','employee'=>'secondary'];
  $c = $map[$role] ?? 'secondary';
  return '<span class="badge bg-'.$c.'">'.e($role).'</span>';
}
