<?php
namespace App\Smart;
use PDO;

class SmartAssist {
  public static function analyze(PDO $db, array $config, string $text): array {
    $t = trim(preg_replace('/\s+/', ' ', $text));
    $summary = mb_substr($t, 0, 240, 'UTF-8') . (mb_strlen($t,'UTF-8')>240 ? '…' : '');

    // Heuristics for priority/category/sentiment (robust offline)
    $lower = mb_strtolower($text,'UTF-8');
    $priority = 'Medium';
    if (preg_match('/urgent|asap|immediately|critical|harassment|security|breach|hack|threat/i', $lower)) $priority='Critical';
    else if (preg_match('/cannot|unable|down|error|not working|failed|delay/i', $lower)) $priority='High';
    else if (preg_match('/request|access|permission|update/i', $lower)) $priority='Low';

    $sentiment='Neutral';
    if (preg_match('/thanks|thank you|great|appreciate/i', $lower)) $sentiment='Positive';
    if (preg_match('/angry|bad|worst|unfair|harassment|issue|complain|delay|not working|problem/i', $lower)) $sentiment='Negative';

    $category='General';
    if (preg_match('/salary|payroll|reimbursement|allowance|invoice|payment/i', $lower)) $category='Finance';
    else if (preg_match('/vpn|laptop|pc|email|server|software|password|internet/i', $lower)) $category='IT Support';
    else if (preg_match('/harassment|bully|hr|manager|leave|policy/i', $lower)) $category='HR';
    else if (preg_match('/security|access|cctv|breach|unauthorized/i', $lower)) $category='Security';
    else if (preg_match('/ac|electric|clean|repair|facility|room/i', $lower)) $category='Facilities';

    $tone = $sentiment==='Negative' ? "We’re sorry for the inconvenience." : ($sentiment==='Positive' ? "Thank you for the feedback." : "Thank you for reaching out.");
    $urg = in_array($priority,['High','Critical'], true) ? "We will prioritize this and respond urgently." : "We will review and update you shortly.";
    $suggested = $tone." Your case is logged under **{$category}** with **{$priority}** priority. ".$urg;

    return [
      'category'=>$category,
      'priority'=>$priority,
      'sentiment'=>$sentiment,
      'summary'=>$summary,
      'suggested_response'=>$suggested,
      'engine'=>'offline-heuristic'
    ];
  }
}
